import { Component } from '@angular/core';
import { RastreioComponent } from './rastreio/rastreio.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RastreioComponent],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'frontend';
}